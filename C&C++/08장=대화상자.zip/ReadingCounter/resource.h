//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ReadingCounter.rc
//
#define IDD_READING                     101
#define IDC_EDSTART                     1000
#define IDC_EDEND                       1001
#define IDC_EDTIME                      1002
#define IDC_BTNSTART                    1003
#define IDC_BTNPAUSE                    1004
#define IDC_STTIME                      1005
#define IDC_CHKBEEP                     1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
