//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Couple3.rc
//
#define IDB_SHAPE1                      101
#define IDB_SHAPE2                      102
#define IDB_SHAPE3                      103
#define IDB_SHAPE4                      104
#define IDB_SHAPE5                      105
#define IDB_SHAPE6                      106
#define IDB_SHAPE7                      107
#define IDB_SHAPE8                      108
#define IDB_SHAPE9                      109
#define IDI_COUPLE                      110

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
