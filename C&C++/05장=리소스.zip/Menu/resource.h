//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Menu.rc
//
#define IDR_MENU1                       102
#define IDC_CURSOR1                     103
#define IDI_ICON1                       104
#define IDR_ACCELERATOR1                105
#define ID_FILE_MENU1                   40001
#define ID_FILE_MENU2                   40002
#define ID_FILE_EXIT                    40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
