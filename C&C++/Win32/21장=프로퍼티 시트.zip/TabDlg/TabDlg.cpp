#include <windows.h>

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK Dlg1Proc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
BOOL CALLBACK Dlg2Proc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass=TEXT("TabDlg");

#include <commctrl.h>
#include "resource.h"
HWND hTab;
HWND hTabDlg;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
	  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;
	
	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)(COLOR_BTNFACE+1);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW | WS_CLIPSIBLINGS,
		CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);
	
	while (GetMessage(&Message,NULL,0,0)) {
		if (!IsWindow(hTabDlg) || !IsDialogMessage(hTabDlg,&Message)) {
			TranslateMessage(&Message);
			DispatchMessage(&Message);
		}
	}
	return (int)Message.wParam;
}

typedef struct {  
  WORD      dlgVer; 
  WORD      signature; 
  DWORD     helpID; 
  DWORD     exStyle; 
  DWORD     style; 
  WORD      cDlgItems; 
  short     x; 
  short     y; 
  short     cx; 
  short     cy; 
//  sz_Or_Ord menu; 
//  sz_Or_Ord windowClass; 
//  WCHAR     title[titleLen]; 
//  WORD     pointsize; 
//  WORD     weight; 
//  BYTE     italic;
//  BYTE     charset; 
//  WCHAR    typeface[stringLen];  
} DLGTEMPLATEEX; 

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	TCITEM tie;
	int Sel;
	HRSRC hRc;
	HGLOBAL hGlb;
	DLGTEMPLATEEX *dTem;
	RECT trt={0,0,0,0};

	switch (iMessage) {
	case WM_CREATE:
		hWndMain=hWnd;
		InitCommonControls();

		hTab=CreateWindow(WC_TABCONTROL,"",WS_CHILD | WS_VISIBLE 
			| WS_CLIPSIBLINGS,
			0,0,0,0,hWnd,(HMENU)0,g_hInst,NULL);

		tie.mask=TCIF_TEXT;
		tie.pszText="one";
		TabCtrl_InsertItem(hTab,0,&tie);
		tie.pszText="two";
		TabCtrl_InsertItem(hTab,1,&tie);

		// ù��° ��ȭ������ ũ�� ����
		hRc=FindResource(NULL,MAKEINTRESOURCE(IDD_DIALOG1),RT_DIALOG);
		hGlb=LoadResource(NULL,hRc);
		dTem=(DLGTEMPLATEEX *)LockResource(hGlb);
		trt.right=dTem->cx;
		trt.bottom=dTem->cy;

		// �ι�° ��ȭ������ ũ�� ���ϰ� �� �� ū ���� ����
		hRc=FindResource(NULL,MAKEINTRESOURCE(IDD_DIALOG2),RT_DIALOG);
		hGlb=LoadResource(NULL,hRc);
		dTem=(DLGTEMPLATEEX *)LockResource(hGlb);
		trt.right=max(trt.right,dTem->cx);
		trt.bottom=max(trt.bottom,dTem->cy);

		// ��ȭ���� ������ �ȼ� ������ �ٲ۴�.
		hTabDlg=CreateDialog(g_hInst,MAKEINTRESOURCE(IDD_DIALOG1),hWnd,Dlg1Proc);
		MapDialogRect(hTabDlg,&trt);
		DestroyWindow(hTabDlg);

		// ǥ�� ������ ������ ũ��� �ٲ۴�.
		TabCtrl_AdjustRect(hTab,TRUE,&trt);

		// ������ ��ǥ�� �������� �ű��.
		OffsetRect(&trt,-trt.left,-trt.top);

		// ���� ũ�⸸ŭ �� ��Ʈ�� ũ�� ����
		SetWindowPos(hTab,NULL,trt.left,trt.top,trt.right,trt.bottom,SWP_NOZORDER);

		hTabDlg=CreateDialog(g_hInst,MAKEINTRESOURCE(IDD_DIALOG1),hWnd,Dlg1Proc);
		return 0;
	case WM_NOTIFY:
		switch (((LPNMHDR)lParam)->code) {
		case TCN_SELCHANGE:
			if (hTabDlg) {
				DestroyWindow(hTabDlg);
			}
			Sel=TabCtrl_GetCurSel(hTab);
			if (Sel==0) {
				hTabDlg=CreateDialog(g_hInst,MAKEINTRESOURCE(IDD_DIALOG1),hWnd,Dlg1Proc);
			} else {
				hTabDlg=CreateDialog(g_hInst,MAKEINTRESOURCE(IDD_DIALOG2),hWnd,Dlg2Proc);
			}
			break;
		}
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd,iMessage,wParam,lParam));
}

// ��ȭ���ڴ� �ݵ�� ���ϵ� ��Ÿ���̾�� �ϸ� ��輱�� ������ �ʴ´�.
BOOL CALLBACK Dlg1Proc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	RECT prt;
	switch (iMessage) {
	case WM_INITDIALOG:
		// ���� ǥ�� ���� ������� �̵��ϸ� �����߿� ���� ���� �ö󰣴�.
		GetWindowRect(hTab,&prt);
		TabCtrl_AdjustRect(hTab,FALSE,&prt);
		ScreenToClient(hWndMain,(LPPOINT)&prt);
		SetWindowPos(hDlg,HWND_TOP,prt.left,prt.top,0,0,SWP_NOSIZE);
		SendDlgItemMessage(hDlg,IDC_COMBO1,CB_ADDSTRING,0,(LPARAM)"¥���");
		SendDlgItemMessage(hDlg,IDC_COMBO1,CB_ADDSTRING,0,(LPARAM)"������");
		SendDlgItemMessage(hDlg,IDC_COMBO1,CB_ADDSTRING,0,(LPARAM)"������");
		SendDlgItemMessage(hDlg,IDC_COMBO1,CB_ADDSTRING,0,(LPARAM)"������");
		SendDlgItemMessage(hDlg,IDC_COMBO1,CB_SETCURSEL,0,0);
		return TRUE;
	// EndDialog�� ȣ���� �ʿ䰡 ����.
	case WM_COMMAND:
		switch (LOWORD(wParam))	{
		case IDC_BUTTON1:
			MessageBox(hDlg,"��ư�� �������ϴ�","�˸�",MB_OK);
			return TRUE;
		}
		return FALSE;
	}
	return FALSE;
}

BOOL CALLBACK Dlg2Proc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	RECT prt;
	switch (iMessage) {
	case WM_INITDIALOG:
		SetWindowPos(hDlg,HWND_TOP,100,100,0,0,SWP_NOSIZE);
		GetWindowRect(hTab,&prt);
		TabCtrl_AdjustRect(hTab,FALSE,&prt);
		ScreenToClient(hWndMain,(LPPOINT)&prt);
		SetWindowPos(hDlg,HWND_TOP,prt.left,prt.top,0,0,SWP_NOSIZE);
		SetWindowText(GetDlgItem(hDlg,IDC_EDIT1),"����Ʈ ��Ʈ���̴�");
		return TRUE;
	}
	return FALSE;
}