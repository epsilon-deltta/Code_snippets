//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TipSetting.rc
//
#define IDD_DIALOG1                     101
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_LIST1                       1002
#define IDC_EDINITIAL                   1003
#define IDC_EDPOPUP                     1004
#define IDC_EDRESHOW                    1005
#define IDC_BTNSETDELAY                 1007
#define IDC_BTNRESET                    1008
#define IDC_BTNBKCOLOR                  1009
#define IDC_BTNTEXTCOLOR                1010
#define IDC_EDLEFT                      1011
#define IDC_EDTOP                       1012
#define IDC_EDRIGHT                     1013
#define IDC_EDBOTTOM                    1014
#define IDC_BTNFONT                     1015
#define IDC_BTNSETMARGIN                1016
#define IDC_EDWIDTH                     1017
#define IDC_BTNSETWIDTH                 1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
